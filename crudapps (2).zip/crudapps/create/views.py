from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
from .models import Employee

# Create your views here.

def index(request):
    return render(request,"create/index.html")

def create(request):
    if request.method == "POST":
        empname = request.POST['empname']
        empdept = request.POST['empdept']
        emppos = request.POST['emppos']
        empsal = request.POST['empsal']
        obj = Employee(empname=empname, empdept=empdept,
                       emppos=emppos, empsal=empsal)
        obj.save()
        return redirect("read")
        #return render(request, "create/insert.html", {"key": "Data Inserted Successfully !"})
    return render(request, "create/read.html")


def insert(request):
    if request.method == "POST":
        empname = request.POST['empname']
        empdept = request.POST['empdept']
        emppos = request.POST['emppos']
        empsal = request.POST['empsal']
        obj = Employee(empname=empname, empdept=empdept,
                       emppos=emppos, empsal=empsal)
        obj.save()
        #return redirect("insert")
        
        return render(request, "create/insert.html", {"key": "Data Inserted Successfully !"})
    return render(request, "create/insert.html")


def read(request):
    if request.session.has_key("loggedid"):
        data = Employee.objects.all()
        data1=Employee.objects.filter(empname=request.session["loggedid"])
        return render(request, "create/read.html", {"res": data})
    else:
        return redirect("login")


def update(request):
    data = Employee.objects.get(pk=request.GET['q'])
    if request.method == "POST":
        data.empname = request.POST["empname"]
        data.empdept = request.POST["empdept"]
        data.emppos = request.POST["emppos"]
        data.empsal = request.POST["empsal"]
        data.save()
        return render(request,"create/update.html",{"key":"Record Updated Successfully !"})
    return render(request, "create/update.html", {"res": data})

def delete(request):
    data=Employee.objects.get(pk=request.GET['q'])
    if request.method=="POST":
        data.delete()
        return redirect("read")
    return render(request,"create/deleteconfirmation.html",{"emp":data})

def login(request):
    if request.method=="POST":
        obj=Employee.objects.filter(empname=request.POST["empname"],empdept=request.POST["empdept"])
        if(obj.count()>0):
            request.session["loggedid"]=request.POST["empname"]
            return redirect("read")
        else:
            return render(request,"create/login.html",{"key":"Invalid Employee Name & Employee Department !"})
    return render(request,"create/login.html")

def logout(request):
    del request.session["loggedid"]
    return redirect("login")