from django.urls import path, include
from . import views

urlpatterns = [
    path("",views.index,name="index"),
    path("create", views.create, name="create"),
    path("read", views.read, name="read"),
    path("update", views.update, name="update"),
    path("delete",views.delete,name="delete"),
    path("login",views.login,name="login"),
    path("logout",views.logout,name="logout"),
    
]
